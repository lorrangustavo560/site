import { CampaignFormData, GeneratedCampaignContent } from '../types';
import { isSupabaseConfigured, supabase } from './supabase';

const shouldUseAiFunction = import.meta.env.VITE_USE_AI_FUNCTION === 'true';

function moneyLabel(value: string) {
  if (!value.trim()) return 'preço especial';
  const clean = value.replace(/[R$\s]/g, '').trim();
  return clean ? `R$ ${clean}` : value;
}

function buildLocalCampaign(data: CampaignFormData): GeneratedCampaignContent {
  const price = moneyLabel(data.price);
  const audience = data.target_audience || 'pessoas que querem melhorar seus resultados';
  const benefit = data.main_benefit || 'alcançar um resultado melhor com praticidade';
  const problem = data.problem_solved || 'falta de tempo, clareza ou direção';
  const product = data.product_name || 'seu produto';

  return {
    title: `${product}: solução prática para ${benefit}`,
    product_description: `${product} é um ${data.product_type.toLowerCase()} criado para ajudar ${audience} a resolver ${problem}. Com uma comunicação ${data.tone.toLowerCase()}, a oferta mostra de forma clara como o cliente pode ${benefit} pagando ${price}.`,
    whatsapp_messages: [
      `Oi! Tenho uma novidade que pode te ajudar com ${problem}. O ${product} foi criado para quem quer ${benefit} de um jeito simples. Está saindo por ${price}. Quer que eu te mande os detalhes?`,
      `Você ainda sofre com ${problem}? O ${product} pode ser o próximo passo para você ${benefit}. Posso te explicar rapidinho como funciona?`,
      `Passando para te mostrar uma oportunidade: ${product}. Ele é ideal para ${audience} e foi pensado para gerar resultado sem complicação. Valor: ${price}.`,
      `Tenho poucas palavras: se você quer ${benefit}, precisa conhecer o ${product}. É direto, prático e feito para resolver ${problem}.`,
      `Quer receber uma explicação rápida sobre o ${product}? Ele ajuda ${audience} a ${benefit} e pode ser exatamente o que você estava procurando.`,
    ],
    instagram_captions: [
      `Você não precisa continuar travado por causa de ${problem}. Com ${product}, o caminho para ${benefit} fica mais simples. Comente “QUERO” para receber os detalhes.`,
      `${audience} precisam de soluções simples, não de promessas vazias. O ${product} foi criado para isso: ajudar você a ${benefit}.`,
      `Se o seu objetivo é ${benefit}, salve este post. O ${product} pode ser o ponto de virada para resolver ${problem}.`,
      `Oferta especial: ${product} por ${price}. Criado para quem quer sair da dúvida e agir com clareza.`,
      `Pare de adiar. O problema de ${problem} pode ser resolvido com um plano mais simples. Conheça o ${product}.`,
    ],
    post_ideas: [
      `Antes e depois: como era lidar com ${problem} antes do ${product} e como fica depois.`,
      `Post carrossel: 5 sinais de que você precisa resolver ${problem} hoje.`,
      `Reels curto: “O erro que impede você de ${benefit}”.`,
      `Post prova social: explique para quem o ${product} serve e quais resultados ele busca facilitar.`,
      `Post direto de oferta: apresente o produto, benefício, preço e chamada para ação.`,
    ],
    ad_headlines: [
      `${product}: resolva ${problem} com praticidade`,
      `Quer ${benefit}? Conheça esta solução`,
      `Oferta por ${price} para ${audience}`,
    ],
    urgency_phrases: [
      `Comece hoje e pare de adiar sua evolução.`,
      `A condição atual pode sair do ar a qualquer momento.`,
      `Quanto antes você agir, mais rápido sai do mesmo lugar.`,
    ],
    ctas: [
      `Quero conhecer agora`,
      `Me envie os detalhes`,
      `Comprar por ${price}`,
    ],
    short_video_script: `Cena 1: Mostre o problema: “Você ainda lida com ${problem}?”\nCena 2: Apresente o produto: “Eu criei o ${product} para ajudar ${audience}.”\nCena 3: Mostre o benefício: “A ideia é te ajudar a ${benefit} sem complicação.”\nCena 4: Oferta: “Hoje está por ${price}.”\nCena 5: Chamada final: “Clique no link ou mande QUERO para receber os detalhes.”`,
  };
}

export async function generateCampaign(data: CampaignFormData): Promise<GeneratedCampaignContent> {
  if (shouldUseAiFunction && isSupabaseConfigured) {
    const { data: response, error } = await supabase.functions.invoke('generate-campaign', {
      body: data,
    });

    if (error) {
      throw new Error(error.message);
    }

    return response as GeneratedCampaignContent;
  }

  await new Promise((resolve) => setTimeout(resolve, 900));
  return buildLocalCampaign(data);
}
