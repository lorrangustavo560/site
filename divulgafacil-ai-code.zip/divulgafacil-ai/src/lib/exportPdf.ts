import jsPDF from 'jspdf';
import { Campaign } from '../types';

function addWrappedText(doc: jsPDF, title: string, text: string | string[], yStart: number) {
  let y = yStart;
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;
  const width = doc.internal.pageSize.getWidth() - margin * 2;

  function ensureSpace(space = 16) {
    if (y + space > pageHeight - margin) {
      doc.addPage();
      y = margin;
    }
  }

  ensureSpace(18);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text(title, margin, y);
  y += 8;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  const items = Array.isArray(text) ? text : [text];

  items.forEach((item, index) => {
    const prefix = Array.isArray(text) ? `${index + 1}. ` : '';
    const lines = doc.splitTextToSize(`${prefix}${item}`, width);
    ensureSpace(lines.length * 6 + 5);
    doc.text(lines, margin, y);
    y += lines.length * 6 + 4;
  });

  return y + 2;
}

export function exportCampaignToPdf(campaign: Campaign) {
  const doc = new jsPDF();
  const content = campaign.generated_content;
  let y = 16;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text('DivulgaFácil AI', 14, y);
  y += 9;

  doc.setFontSize(14);
  doc.text(content.title, 14, y);
  y += 10;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Produto: ${campaign.product_name}`, 14, y);
  y += 6;
  doc.text(`Canal: ${campaign.channel} | Tom: ${campaign.tone}`, 14, y);
  y += 8;

  y = addWrappedText(doc, 'Descrição do Produto', content.product_description, y);
  y = addWrappedText(doc, 'Mensagens para WhatsApp', content.whatsapp_messages, y);
  y = addWrappedText(doc, 'Legendas para Instagram', content.instagram_captions, y);
  y = addWrappedText(doc, 'Ideias de Posts', content.post_ideas, y);
  y = addWrappedText(doc, 'Chamadas de Anúncio', content.ad_headlines, y);
  y = addWrappedText(doc, 'Frases de Urgência', content.urgency_phrases, y);
  y = addWrappedText(doc, 'CTAs', content.ctas, y);
  addWrappedText(doc, 'Roteiro de Vídeo Curto', content.short_video_script, y);

  doc.save(`${campaign.product_name || 'campanha'}-divulgafacil.pdf`);
}
