import { Campaign, CampaignFormData, GeneratedCampaignContent, UserProfile } from '../types';
import { isSupabaseConfigured, supabase } from './supabase';

const LOCAL_CAMPAIGNS_KEY = 'divulgafacil_campaigns';

function readLocalCampaigns(): Campaign[] {
  const raw = localStorage.getItem(LOCAL_CAMPAIGNS_KEY);
  if (!raw) return [];

  try {
    return JSON.parse(raw) as Campaign[];
  } catch {
    return [];
  }
}

function writeLocalCampaigns(campaigns: Campaign[]) {
  localStorage.setItem(LOCAL_CAMPAIGNS_KEY, JSON.stringify(campaigns));
}

export async function listCampaigns(userId: string): Promise<Campaign[]> {
  if (!isSupabaseConfigured) {
    return readLocalCampaigns()
      .filter((campaign) => campaign.user_id === userId)
      .sort((a, b) => Number(new Date(b.created_at)) - Number(new Date(a.created_at)));
  }

  const { data, error } = await supabase
    .from('campaigns')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return (data || []) as Campaign[];
}

export async function getCampaign(id: string, userId: string): Promise<Campaign | null> {
  if (!isSupabaseConfigured) {
    return readLocalCampaigns().find((campaign) => campaign.id === id && campaign.user_id === userId) || null;
  }

  const { data, error } = await supabase
    .from('campaigns')
    .select('*')
    .eq('id', id)
    .eq('user_id', userId)
    .single();

  if (error) return null;
  return data as Campaign;
}

export async function createCampaign(
  user: UserProfile,
  form: CampaignFormData,
  generated: GeneratedCampaignContent
): Promise<Campaign> {
  const payload = {
    user_id: user.id,
    product_name: form.product_name,
    product_type: form.product_type,
    price: form.price,
    target_audience: form.target_audience,
    main_benefit: form.main_benefit,
    problem_solved: form.problem_solved,
    tone: form.tone,
    channel: form.channel,
    generated_content: generated,
  };

  if (!isSupabaseConfigured) {
    const campaign: Campaign = {
      id: crypto.randomUUID(),
      ...payload,
      created_at: new Date().toISOString(),
    };

    const campaigns = readLocalCampaigns();
    campaigns.unshift(campaign);
    writeLocalCampaigns(campaigns);
    return campaign;
  }

  const { data, error } = await supabase.from('campaigns').insert(payload).select('*').single();

  if (error) throw new Error(error.message);
  return data as Campaign;
}

export async function deleteCampaign(id: string, userId: string) {
  if (!isSupabaseConfigured) {
    writeLocalCampaigns(readLocalCampaigns().filter((campaign) => !(campaign.id === id && campaign.user_id === userId)));
    return;
  }

  const { error } = await supabase.from('campaigns').delete().eq('id', id).eq('user_id', userId);
  if (error) throw new Error(error.message);
}

export async function countCampaignsThisMonth(userId: string): Promise<number> {
  const start = new Date();
  start.setDate(1);
  start.setHours(0, 0, 0, 0);

  if (!isSupabaseConfigured) {
    return readLocalCampaigns().filter(
      (campaign) => campaign.user_id === userId && new Date(campaign.created_at) >= start
    ).length;
  }

  const { count, error } = await supabase
    .from('campaigns')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .gte('created_at', start.toISOString());

  if (error) throw new Error(error.message);
  return count || 0;
}
