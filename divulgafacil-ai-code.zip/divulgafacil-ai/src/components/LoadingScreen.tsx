export function LoadingScreen() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950">
      <div className="text-center">
        <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-brand-500/30 border-t-brand-400" />
        <p className="mt-4 text-sm text-slate-400">Carregando...</p>
      </div>
    </div>
  );
}
