import { Calendar, Eye, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Link } from 'react-router-dom';
import { Campaign } from '../types';
import { Button } from './Button';
import { Card } from './Card';

interface CampaignCardProps {
  campaign: Campaign;
  onDelete?: (id: string) => void;
}

export function CampaignCard({ campaign, onDelete }: CampaignCardProps) {
  return (
    <Card className="flex h-full flex-col">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <p className="mb-2 inline-flex rounded-full bg-brand-500/10 px-3 py-1 text-xs font-semibold text-brand-200">
            {campaign.channel}
          </p>
          <h3 className="text-xl font-black text-white">{campaign.product_name}</h3>
          <p className="mt-1 text-sm text-slate-400">{campaign.product_type} · {campaign.tone}</p>
        </div>
      </div>

      <p className="line-clamp-3 flex-1 text-sm leading-6 text-slate-300">
        {campaign.generated_content.product_description}
      </p>

      <div className="mt-5 flex items-center gap-2 text-xs text-slate-500">
        <Calendar size={14} />
        {format(new Date(campaign.created_at), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
      </div>

      <div className="mt-5 flex gap-2">
        <Link to={`/campanhas/${campaign.id}`} className="flex-1">
          <Button variant="secondary" full>
            <Eye size={16} />
            Abrir
          </Button>
        </Link>
        {onDelete && (
          <Button variant="danger" onClick={() => onDelete(campaign.id)} aria-label="Excluir campanha">
            <Trash2 size={16} />
          </Button>
        )}
      </div>
    </Card>
  );
}
