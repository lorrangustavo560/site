import { PlanName } from '../types';

const labels: Record<PlanName, string> = {
  free: 'Gratuito',
  pro: 'Pro',
  premium: 'Premium',
};

export function PlanBadge({ plan }: { plan: PlanName }) {
  return (
    <span className="inline-flex items-center rounded-full border border-brand-400/40 bg-brand-500/10 px-3 py-1 text-xs font-semibold text-brand-100">
      {labels[plan]}
    </span>
  );
}
