import { BarChart3, CreditCard, Home, Library, LogOut, Menu, PlusCircle, Settings, X } from 'lucide-react';
import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './Button';
import { PlanBadge } from './PlanBadge';

const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: BarChart3 },
  { href: '/nova-campanha', label: 'Nova campanha', icon: PlusCircle },
  { href: '/campanhas', label: 'Minhas campanhas', icon: Library },
  { href: '/planos', label: 'Planos', icon: CreditCard },
  { href: '/configuracoes', label: 'Configurações', icon: Settings },
];

export function Sidebar() {
  const [open, setOpen] = useState(false);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  async function handleSignOut() {
    await signOut();
    navigate('/');
  }

  const content = (
    <aside className="flex h-full flex-col border-r border-white/10 bg-slate-950/95 p-5 backdrop-blur-xl">
      <div className="mb-8 flex items-center justify-between gap-3">
        <NavLink to="/dashboard" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-brand-600 font-black shadow-glow">D</div>
          <div>
            <p className="font-black text-white">DivulgaFácil</p>
            <p className="text-xs text-brand-200">AI SaaS</p>
          </div>
        </NavLink>
        <button className="rounded-xl p-2 text-slate-300 hover:bg-white/10 md:hidden" onClick={() => setOpen(false)}>
          <X size={20} />
        </button>
      </div>

      <nav className="flex-1 space-y-2">
        <NavLink
          to="/"
          onClick={() => setOpen(false)}
          className="flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold text-slate-300 transition hover:bg-white/10 hover:text-white"
        >
          <Home size={18} />
          Início
        </NavLink>
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.href}
              to={item.href}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition ${
                  isActive ? 'bg-brand-600 text-white shadow-glow' : 'text-slate-300 hover:bg-white/10 hover:text-white'
                }`
              }
            >
              <Icon size={18} />
              {item.label}
            </NavLink>
          );
        })}
      </nav>

      {user && (
        <div className="rounded-3xl border border-white/10 bg-white/[0.05] p-4">
          <div className="mb-3 flex items-center justify-between gap-2">
            <div className="min-w-0">
              <p className="truncate text-sm font-bold text-white">{user.name}</p>
              <p className="truncate text-xs text-slate-400">{user.email}</p>
            </div>
            <PlanBadge plan={user.plan} />
          </div>
          <Button variant="ghost" size="sm" full onClick={handleSignOut}>
            <LogOut size={16} />
            Sair
          </Button>
        </div>
      )}
    </aside>
  );

  return (
    <>
      <button
        className="fixed left-4 top-4 z-40 rounded-2xl border border-white/10 bg-slate-950/90 p-3 text-white shadow-xl backdrop-blur md:hidden"
        onClick={() => setOpen(true)}
      >
        <Menu size={20} />
      </button>
      <div className="hidden h-screen w-72 shrink-0 md:sticky md:top-0 md:block">{content}</div>
      {open && <div className="fixed inset-0 z-50 bg-black/60 md:hidden" onClick={() => setOpen(false)} />}
      <div className={`fixed inset-y-0 left-0 z-50 w-80 transition md:hidden ${open ? 'translate-x-0' : '-translate-x-full'}`}>
        {content}
      </div>
    </>
  );
}
