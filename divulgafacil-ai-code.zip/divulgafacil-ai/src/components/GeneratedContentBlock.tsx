import { CopyButton } from './CopyButton';

interface GeneratedContentBlockProps {
  title: string;
  content: string | string[];
}

export function GeneratedContentBlock({ title, content }: GeneratedContentBlockProps) {
  const normalized = Array.isArray(content) ? content : [content];
  const copyText = normalized.join('\n\n');

  return (
    <section className="rounded-3xl border border-white/10 bg-black/25 p-5">
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h3 className="text-lg font-bold text-white">{title}</h3>
        <CopyButton text={copyText} />
      </div>
      <div className="space-y-3">
        {normalized.map((item, index) => (
          <div key={`${title}-${index}`} className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-sm leading-6 text-slate-200">
            {Array.isArray(content) && <span className="mr-2 font-bold text-brand-300">{index + 1}.</span>}
            <span className="whitespace-pre-line">{item}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
