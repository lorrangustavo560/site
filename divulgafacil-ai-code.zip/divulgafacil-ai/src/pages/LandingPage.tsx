import { ArrowRight, CheckCircle2, Sparkles, Zap, MessageSquare, Instagram, Megaphone, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { useAuth } from '../contexts/AuthContext';

const benefits = [
  { icon: MessageSquare, title: 'Mensagens para WhatsApp', text: 'Textos prontos para chamar clientes sem parecer robô.' },
  { icon: Instagram, title: 'Legendas para Instagram', text: 'Posts, chamadas e descrições para vender todos os dias.' },
  { icon: Megaphone, title: 'Anúncios prontos', text: 'Crie títulos, CTAs e frases de urgência para campanhas.' },
  { icon: FileText, title: 'Exportação em PDF', text: 'Transforme sua campanha em um material organizado.' },
];

const steps = [
  'Cadastre o produto ou serviço',
  'Escolha canal, público e tom',
  'Copie e divulgue a campanha pronta',
];

export function LandingPage() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen overflow-hidden">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-4 py-6">
        <Link to="/" className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-600 font-black shadow-glow">D</div>
          <div>
            <p className="font-black text-white">DivulgaFácil AI</p>
            <p className="text-xs text-brand-200">micro SaaS de campanhas</p>
          </div>
        </Link>
        <div className="flex items-center gap-2">
          {user ? (
            <Link to="/dashboard">
              <Button>Dashboard</Button>
            </Link>
          ) : (
            <>
              <Link to="/login" className="hidden sm:block">
                <Button variant="ghost">Entrar</Button>
              </Link>
              <Link to="/cadastro">
                <Button>Começar agora</Button>
              </Link>
            </>
          )}
        </div>
      </header>

      <main>
        <section className="mx-auto grid max-w-7xl gap-10 px-4 py-16 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:py-24">
          <div>
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand-400/30 bg-brand-500/10 px-4 py-2 text-sm font-semibold text-brand-100">
              <Sparkles size={16} />
              Campanhas prontas em minutos
            </div>
            <h1 className="max-w-4xl text-4xl font-black leading-tight text-white sm:text-6xl">
              Crie campanhas de divulgação em minutos com IA
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300">
              Gere textos, mensagens, ideias de posts, anúncios e roteiros prontos para vender seu produto todos os dias.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link to={user ? '/nova-campanha' : '/cadastro'}>
                <Button size="lg">
                  Começar gratuitamente
                  <ArrowRight size={18} />
                </Button>
              </Link>
              <a href="#planos">
                <Button size="lg" variant="secondary">Ver planos</Button>
              </a>
            </div>
          </div>

          <Card className="relative overflow-hidden">
            <div className="absolute -right-20 -top-20 h-56 w-56 rounded-full bg-brand-500/25 blur-3xl" />
            <div className="relative">
              <p className="mb-4 text-sm font-semibold uppercase tracking-[0.28em] text-brand-200">Prévia da campanha</p>
              <div className="space-y-4">
                {[
                  'Título chamativo para vender seu PDF',
                  '5 mensagens para WhatsApp prontas',
                  '5 legendas para Instagram com CTA',
                  'Roteiro curto para vídeo de 30 segundos',
                ].map((item) => (
                  <div key={item} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/25 p-4">
                    <CheckCircle2 className="text-brand-300" size={20} />
                    <span className="text-sm text-slate-200">{item}</span>
                  </div>
                ))}
              </div>
              <div className="mt-6 rounded-3xl bg-brand-600/20 p-5">
                <p className="text-sm text-brand-100">“Pare de travar na divulgação. Preencha as informações e receba tudo pronto para copiar e postar.”</p>
              </div>
            </div>
          </Card>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-12">
          <div className="mb-8 text-center">
            <p className="font-semibold text-brand-300">Benefícios</p>
            <h2 className="mt-2 text-3xl font-black text-white">Tudo que você precisa para divulgar melhor</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {benefits.map((benefit) => {
              const Icon = benefit.icon;
              return (
                <Card key={benefit.title}>
                  <Icon className="mb-4 text-brand-300" size={28} />
                  <h3 className="font-bold text-white">{benefit.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-slate-400">{benefit.text}</p>
                </Card>
              );
            })}
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-12">
          <Card>
            <div className="grid gap-8 lg:grid-cols-3">
              {steps.map((step, index) => (
                <div key={step} className="flex gap-4">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-brand-600 font-black text-white">
                    {index + 1}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">{step}</h3>
                    <p className="mt-2 text-sm text-slate-400">Processo simples para quem quer vender sem complicar.</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </section>

        <section id="planos" className="mx-auto max-w-7xl px-4 py-16">
          <div className="mb-8 text-center">
            <p className="font-semibold text-brand-300">Planos</p>
            <h2 className="mt-2 text-3xl font-black text-white">Comece grátis e evolua quando precisar</h2>
          </div>
          <div className="grid gap-4 lg:grid-cols-3">
            {[
              ['Gratuito', 'R$ 0', ['3 campanhas por mês', 'Textos básicos', 'Dashboard simples']],
              ['Pro', 'R$ 19,90/mês', ['Campanhas ilimitadas', 'Exportação em PDF', 'Histórico completo']],
              ['Premium', 'R$ 39,90/mês', ['Tudo do Pro', 'Modelos avançados', 'Suporte prioritário']],
            ].map(([plan, price, features]) => (
              <Card key={plan as string} className={plan === 'Pro' ? 'border-brand-400/50 shadow-glow' : ''}>
                <h3 className="text-2xl font-black text-white">{plan as string}</h3>
                <p className="mt-2 text-3xl font-black text-brand-200">{price as string}</p>
                <ul className="mt-6 space-y-3">
                  {(features as string[]).map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-slate-300">
                      <CheckCircle2 size={18} className="text-brand-300" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t border-white/10 px-4 py-8 text-center text-sm text-slate-500">
        DivulgaFácil AI © {new Date().getFullYear()} — Feito para pequenos vendedores venderem melhor.
      </footer>
    </div>
  );
}
