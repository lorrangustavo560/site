import { FormEvent, useState } from 'react';
import { Save } from 'lucide-react';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { useAuth } from '../contexts/AuthContext';
import { CampaignTone } from '../types';

const tones: CampaignTone[] = ['Persuasivo', 'Profissional', 'Jovem', 'Urgente', 'Emocional', 'Simples'];

export function SettingsPage() {
  const { user, updateProfile } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [tone, setTone] = useState<CampaignTone>('Persuasivo');
  const [saved, setSaved] = useState(false);

  if (!user) return null;

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    await updateProfile({ name });
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-black text-white">Configurações</h1>
        <p className="mt-2 text-slate-400">Edite seu perfil e preferências da plataforma.</p>
      </div>

      <Card className="max-w-3xl">
        <form className="space-y-5" onSubmit={handleSubmit}>
          <div>
            <label className="label-base" htmlFor="name">Nome</label>
            <input id="name" className="input-base" value={name} onChange={(event) => setName(event.target.value)} />
          </div>
          <div>
            <label className="label-base" htmlFor="email">E-mail</label>
            <input id="email" className="input-base" value={user.email} disabled />
          </div>
          <div>
            <label className="label-base" htmlFor="plan">Plano atual</label>
            <input id="plan" className="input-base capitalize" value={user.plan} disabled />
          </div>
          <div>
            <label className="label-base" htmlFor="tone">Tom padrão de comunicação</label>
            <select id="tone" className="input-base" value={tone} onChange={(event) => setTone(event.target.value as CampaignTone)}>
              {tones.map((item) => <option key={item}>{item}</option>)}
            </select>
            <p className="mt-2 text-xs text-slate-500">Esta preferência está pronta para ser usada em uma futura automação do formulário.</p>
          </div>
          <Button type="submit">
            <Save size={18} />
            {saved ? 'Salvo' : 'Salvar alterações'}
          </Button>
        </form>
      </Card>
    </div>
  );
}
