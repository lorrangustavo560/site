import { Download, RefreshCcw } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { GeneratedContentBlock } from '../components/GeneratedContentBlock';
import { useAuth } from '../contexts/AuthContext';
import { exportCampaignToPdf } from '../lib/exportPdf';
import { getCampaign } from '../lib/campaigns';
import { Campaign } from '../types';

export function CampaignResultPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id || !user) return;
    getCampaign(id, user.id)
      .then(setCampaign)
      .finally(() => setLoading(false));
  }, [id, user]);

  if (loading) return <p className="text-slate-400">Carregando campanha...</p>;

  if (!campaign) {
    return (
      <Card className="text-center">
        <p className="text-lg font-bold text-white">Campanha não encontrada.</p>
        <Link to="/campanhas" className="mt-5 inline-block">
          <Button>Voltar para campanhas</Button>
        </Link>
      </Card>
    );
  }

  const content = campaign.generated_content;
  const canExportPdf = user?.plan === 'pro' || user?.plan === 'premium';

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <p className="mb-2 text-sm font-semibold text-brand-300">Campanha gerada</p>
          <h1 className="text-3xl font-black text-white">{content.title}</h1>
          <p className="mt-2 text-slate-400">{campaign.product_name} · {campaign.channel} · {campaign.tone}</p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row">
          <Button variant="secondary" onClick={() => navigate('/nova-campanha')}>
            <RefreshCcw size={18} />
            Gerar outra
          </Button>
          <Button
            onClick={() => (canExportPdf ? exportCampaignToPdf(campaign) : navigate('/planos'))}
            title={canExportPdf ? 'Exportar PDF' : 'Disponível nos planos Pro e Premium'}
          >
            <Download size={18} />
            {canExportPdf ? 'Exportar PDF' : 'Liberar PDF'}
          </Button>
        </div>
      </div>

      <div className="space-y-5">
        <GeneratedContentBlock title="Descrição do produto" content={content.product_description} />
        <GeneratedContentBlock title="Mensagens para WhatsApp" content={content.whatsapp_messages} />
        <GeneratedContentBlock title="Legendas para Instagram" content={content.instagram_captions} />
        <GeneratedContentBlock title="Ideias de posts" content={content.post_ideas} />
        <GeneratedContentBlock title="Chamadas de anúncio" content={content.ad_headlines} />
        <GeneratedContentBlock title="Frases de urgência" content={content.urgency_phrases} />
        <GeneratedContentBlock title="CTAs" content={content.ctas} />
        <GeneratedContentBlock title="Roteiro curto para vídeo" content={content.short_video_script} />
      </div>
    </div>
  );
}
