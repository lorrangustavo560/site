import { ArrowRight, FileText, Instagram, MessageCircle, Megaphone, Plus, Video } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/Button';
import { CampaignCard } from '../components/CampaignCard';
import { Card } from '../components/Card';
import { PlanBadge } from '../components/PlanBadge';
import { useAuth } from '../contexts/AuthContext';
import { listCampaigns } from '../lib/campaigns';
import { Campaign } from '../types';

const shortcuts = [
  { label: 'Mensagem para WhatsApp', icon: MessageCircle },
  { label: 'Legenda para Instagram', icon: Instagram },
  { label: 'Criar anúncio', icon: Megaphone },
  { label: 'Ideia de post', icon: FileText },
  { label: 'Roteiro de vídeo curto', icon: Video },
];

export function DashboardPage() {
  const { user } = useAuth();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    listCampaigns(user.id)
      .then(setCampaigns)
      .finally(() => setLoading(false));
  }, [user]);

  if (!user) return null;

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="mb-3 flex items-center gap-3">
            <h1 className="text-3xl font-black text-white">Olá, {user.name}</h1>
            <PlanBadge plan={user.plan} />
          </div>
          <p className="text-slate-400">Crie campanhas melhores, salve seus textos e divulgue com mais velocidade.</p>
        </div>
        <Link to="/nova-campanha">
          <Button size="lg">
            <Plus size={18} />
            Criar nova campanha
          </Button>
        </Link>
      </div>

      <div className="mb-8 grid gap-4 md:grid-cols-3">
        <Card>
          <p className="text-sm text-slate-400">Campanhas criadas</p>
          <p className="mt-2 text-4xl font-black text-white">{campaigns.length}</p>
        </Card>
        <Card>
          <p className="text-sm text-slate-400">Plano atual</p>
          <p className="mt-2 text-4xl font-black capitalize text-white">{user.plan}</p>
        </Card>
        <Card>
          <p className="text-sm text-slate-400">Status</p>
          <p className="mt-2 text-4xl font-black text-emerald-300">Ativo</p>
        </Card>
      </div>

      <div className="mb-8">
        <h2 className="mb-4 text-xl font-black text-white">Atalhos rápidos</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {shortcuts.map((shortcut) => {
            const Icon = shortcut.icon;
            return (
              <Link key={shortcut.label} to="/nova-campanha">
                <Card className="h-full p-4 transition hover:-translate-y-1 hover:border-brand-400/40">
                  <Icon className="mb-3 text-brand-300" size={24} />
                  <p className="text-sm font-bold text-white">{shortcut.label}</p>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>

      <div className="flex items-center justify-between gap-3">
        <h2 className="text-xl font-black text-white">Campanhas recentes</h2>
        <Link to="/campanhas" className="text-sm font-bold text-brand-300 hover:text-brand-200">
          Ver todas <ArrowRight className="inline" size={14} />
        </Link>
      </div>

      {loading ? (
        <p className="mt-6 text-slate-400">Carregando campanhas...</p>
      ) : campaigns.length === 0 ? (
        <Card className="mt-4 text-center">
          <p className="text-lg font-bold text-white">Você ainda não criou campanhas.</p>
          <p className="mt-2 text-slate-400">Crie a primeira agora e receba textos prontos para divulgação.</p>
          <Link to="/nova-campanha" className="mt-5 inline-block">
            <Button>Criar primeira campanha</Button>
          </Link>
        </Card>
      ) : (
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          {campaigns.slice(0, 3).map((campaign) => (
            <CampaignCard key={campaign.id} campaign={campaign} />
          ))}
        </div>
      )}
    </div>
  );
}
