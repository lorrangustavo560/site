import { FormEvent, useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { AlertCircle, Loader2 } from 'lucide-react';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { useAuth } from '../contexts/AuthContext';
import { isSupabaseConfigured } from '../lib/supabase';

export function AuthPage({ mode }: { mode: 'login' | 'signup' }) {
  const isSignup = mode === 'signup';
  const navigate = useNavigate();
  const { user, signIn, signUp } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (user) return <Navigate to="/dashboard" replace />;

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isSignup) {
        await signUp(name, email, password);
      } else {
        await signIn(email, password);
      }
      navigate('/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Não foi possível entrar. Tente novamente.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-4 py-10">
      <Card className="w-full max-w-md">
        <Link to="/" className="mb-8 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-600 font-black shadow-glow">D</div>
          <div>
            <p className="font-black text-white">DivulgaFácil AI</p>
            <p className="text-xs text-brand-200">Campanhas com IA</p>
          </div>
        </Link>

        <h1 className="text-3xl font-black text-white">{isSignup ? 'Criar conta' : 'Entrar'}</h1>
        <p className="mt-2 text-sm text-slate-400">
          {isSignup ? 'Comece a criar campanhas em poucos minutos.' : 'Acesse seu painel e continue divulgando.'}
        </p>

        {!isSupabaseConfigured && (
          <div className="mt-5 rounded-2xl border border-amber-400/30 bg-amber-500/10 p-4 text-sm text-amber-100">
            Modo demonstração ativo. Configure o Supabase no arquivo .env para usar autenticação real.
          </div>
        )}

        {error && (
          <div className="mt-5 flex gap-3 rounded-2xl border border-rose-400/30 bg-rose-500/10 p-4 text-sm text-rose-100">
            <AlertCircle size={18} />
            {error}
          </div>
        )}

        <form className="mt-6 space-y-4" onSubmit={handleSubmit}>
          {isSignup && (
            <div>
              <label className="label-base" htmlFor="name">Nome</label>
              <input
                id="name"
                className="input-base"
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Seu nome"
                required
              />
            </div>
          )}
          <div>
            <label className="label-base" htmlFor="email">E-mail</label>
            <input
              id="email"
              className="input-base"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="voce@email.com"
              required
            />
          </div>
          <div>
            <label className="label-base" htmlFor="password">Senha</label>
            <input
              id="password"
              className="input-base"
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="mínimo 6 caracteres"
              minLength={6}
              required
            />
          </div>
          <Button type="submit" full disabled={loading}>
            {loading && <Loader2 className="animate-spin" size={18} />}
            {isSignup ? 'Criar conta grátis' : 'Entrar agora'}
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-slate-400">
          {isSignup ? 'Já tem conta?' : 'Ainda não tem conta?'}{' '}
          <Link className="font-bold text-brand-300 hover:text-brand-200" to={isSignup ? '/login' : '/cadastro'}>
            {isSignup ? 'Entrar' : 'Criar conta'}
          </Link>
        </p>
      </Card>
    </main>
  );
}
