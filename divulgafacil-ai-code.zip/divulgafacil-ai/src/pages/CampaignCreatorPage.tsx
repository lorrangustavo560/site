import { FormEvent, useEffect, useState } from 'react';
import { AlertTriangle, Loader2, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { useAuth } from '../contexts/AuthContext';
import { generateCampaign } from '../lib/ai';
import { countCampaignsThisMonth, createCampaign } from '../lib/campaigns';
import { CampaignChannel, CampaignFormData, CampaignTone, ProductType } from '../types';

const productTypes: ProductType[] = ['PDF', 'Curso', 'Serviço', 'Produto físico', 'Mentoria', 'Outro'];
const tones: CampaignTone[] = ['Persuasivo', 'Profissional', 'Jovem', 'Urgente', 'Emocional', 'Simples'];
const channels: CampaignChannel[] = ['WhatsApp', 'Instagram', 'TikTok', 'Facebook', 'Anúncio pago', 'Página de vendas'];

const initialForm: CampaignFormData = {
  product_name: '',
  product_type: 'PDF',
  price: '',
  target_audience: '',
  main_benefit: '',
  problem_solved: '',
  tone: 'Persuasivo',
  channel: 'WhatsApp',
};

export function CampaignCreatorPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState<CampaignFormData>(initialForm);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [monthlyCount, setMonthlyCount] = useState(0);

  useEffect(() => {
    if (!user) return;
    countCampaignsThisMonth(user.id).then(setMonthlyCount);
  }, [user]);

  if (!user) return null;

  const reachedFreeLimit = user.plan === 'free' && monthlyCount >= 3;

  function updateField<K extends keyof CampaignFormData>(key: K, value: CampaignFormData[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');

    if (reachedFreeLimit) {
      setError('Você atingiu o limite de 3 campanhas no plano gratuito. Faça upgrade para continuar.');
      return;
    }

    setLoading(true);
    try {
      const generated = await generateCampaign(form);
      const campaign = await createCampaign(user, form, generated);
      navigate(`/campanhas/${campaign.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao gerar campanha. Tente novamente.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <div className="mb-8">
        <p className="mb-2 flex items-center gap-2 font-semibold text-brand-300">
          <Sparkles size={18} />
          Gerador de campanha
        </p>
        <h1 className="text-3xl font-black text-white">Criar nova campanha</h1>
        <p className="mt-2 text-slate-400">Preencha os dados do produto para gerar textos completos de divulgação.</p>
      </div>

      {reachedFreeLimit && (
        <Card className="mb-6 border-amber-400/40 bg-amber-500/10">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex gap-3">
              <AlertTriangle className="shrink-0 text-amber-300" />
              <div>
                <p className="font-bold text-white">Limite gratuito atingido</p>
                <p className="mt-1 text-sm text-amber-100">Você usou suas 3 campanhas do mês. Vá para planos e simule um upgrade.</p>
              </div>
            </div>
            <Button type="button" onClick={() => navigate('/planos')}>Ver planos</Button>
          </div>
        </Card>
      )}

      {error && (
        <div className="mb-6 rounded-2xl border border-rose-400/30 bg-rose-500/10 p-4 text-sm text-rose-100">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <Card>
          <div className="grid gap-5 md:grid-cols-2">
            <div>
              <label className="label-base" htmlFor="product_name">Nome do produto ou serviço</label>
              <input
                id="product_name"
                className="input-base"
                value={form.product_name}
                onChange={(event) => updateField('product_name', event.target.value)}
                placeholder="Ex: Guia de Renda Extra"
                required
              />
            </div>

            <div>
              <label className="label-base" htmlFor="product_type">Tipo de produto</label>
              <select
                id="product_type"
                className="input-base"
                value={form.product_type}
                onChange={(event) => updateField('product_type', event.target.value as ProductType)}
              >
                {productTypes.map((type) => <option key={type}>{type}</option>)}
              </select>
            </div>

            <div>
              <label className="label-base" htmlFor="price">Preço</label>
              <input
                id="price"
                className="input-base"
                value={form.price}
                onChange={(event) => updateField('price', event.target.value)}
                placeholder="Ex: 19,90"
                required
              />
            </div>

            <div>
              <label className="label-base" htmlFor="target_audience">Público-alvo</label>
              <input
                id="target_audience"
                className="input-base"
                value={form.target_audience}
                onChange={(event) => updateField('target_audience', event.target.value)}
                placeholder="Ex: pessoas que querem vender online"
                required
              />
            </div>

            <div>
              <label className="label-base" htmlFor="main_benefit">Principal benefício</label>
              <input
                id="main_benefit"
                className="input-base"
                value={form.main_benefit}
                onChange={(event) => updateField('main_benefit', event.target.value)}
                placeholder="Ex: começar a vender ainda hoje"
                required
              />
            </div>

            <div>
              <label className="label-base" htmlFor="problem_solved">Problema que resolve</label>
              <input
                id="problem_solved"
                className="input-base"
                value={form.problem_solved}
                onChange={(event) => updateField('problem_solved', event.target.value)}
                placeholder="Ex: não saber divulgar o próprio produto"
                required
              />
            </div>

            <div>
              <label className="label-base" htmlFor="tone">Tom da comunicação</label>
              <select
                id="tone"
                className="input-base"
                value={form.tone}
                onChange={(event) => updateField('tone', event.target.value as CampaignTone)}
              >
                {tones.map((tone) => <option key={tone}>{tone}</option>)}
              </select>
            </div>

            <div>
              <label className="label-base" htmlFor="channel">Canal principal</label>
              <select
                id="channel"
                className="input-base"
                value={form.channel}
                onChange={(event) => updateField('channel', event.target.value as CampaignChannel)}
              >
                {channels.map((channel) => <option key={channel}>{channel}</option>)}
              </select>
            </div>
          </div>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-end">
            <Button type="button" variant="ghost" onClick={() => setForm(initialForm)}>Limpar</Button>
            <Button type="submit" disabled={loading || reachedFreeLimit}>
              {loading && <Loader2 className="animate-spin" size={18} />}
              Gerar campanha completa
            </Button>
          </div>
        </Card>
      </form>
    </div>
  );
}
