import { Link } from 'react-router-dom';
import { Button } from '../components/Button';
import { Card } from '../components/Card';

export function NotFoundPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <Card className="max-w-md text-center">
        <p className="text-6xl font-black text-brand-300">404</p>
        <h1 className="mt-4 text-2xl font-black text-white">Página não encontrada</h1>
        <p className="mt-2 text-slate-400">O caminho acessado não existe.</p>
        <Link to="/dashboard" className="mt-6 inline-block">
          <Button>Voltar ao dashboard</Button>
        </Link>
      </Card>
    </main>
  );
}
