import { CheckCircle2, Sparkles } from 'lucide-react';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { useAuth } from '../contexts/AuthContext';
import { PlanName } from '../types';

const plans: Array<{
  id: PlanName;
  name: string;
  price: string;
  description: string;
  features: string[];
  highlighted?: boolean;
}> = [
  {
    id: 'free',
    name: 'Gratuito',
    price: 'R$ 0',
    description: 'Para testar o SaaS e gerar as primeiras campanhas.',
    features: ['3 campanhas por mês', 'Textos básicos', 'Sem exportação PDF'],
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 'R$ 19,90/mês',
    description: 'Para quem divulga com frequência e quer salvar tempo.',
    features: ['Campanhas ilimitadas', 'Exportação em PDF', 'Textos mais persuasivos', 'Histórico completo'],
    highlighted: true,
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 'R$ 39,90/mês',
    description: 'Para vendedores e freelancers que querem mais recursos.',
    features: ['Tudo do Pro', 'Modelos avançados', 'Suporte prioritário', 'Mais formatos de campanhas'],
  },
];

export function PricingPage() {
  const { user, updateProfile } = useAuth();

  async function handleSelectPlan(plan: PlanName) {
    await updateProfile({ plan });
    alert(`Plano alterado para ${plan}. Esta é uma simulação. Para cobrar de verdade, conecte Stripe, Mercado Pago ou Asaas.`);
  }

  return (
    <div>
      <div className="mb-8 text-center">
        <p className="mb-2 flex items-center justify-center gap-2 font-semibold text-brand-300">
          <Sparkles size={18} />
          Planos do SaaS
        </p>
        <h1 className="text-3xl font-black text-white">Escolha como quer crescer</h1>
        <p className="mx-auto mt-2 max-w-2xl text-slate-400">
          O pagamento real ainda precisa ser conectado. Por enquanto, o botão simula o upgrade para testar as regras do sistema.
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        {plans.map((plan) => (
          <Card key={plan.id} className={`relative ${plan.highlighted ? 'border-brand-400/60 shadow-glow' : ''}`}>
            {plan.highlighted && (
              <span className="absolute right-5 top-5 rounded-full bg-brand-600 px-3 py-1 text-xs font-bold text-white">Mais vendido</span>
            )}
            <h2 className="text-2xl font-black text-white">{plan.name}</h2>
            <p className="mt-2 text-slate-400">{plan.description}</p>
            <p className="mt-6 text-3xl font-black text-brand-200">{plan.price}</p>
            <ul className="mt-6 space-y-3">
              {plan.features.map((feature) => (
                <li key={feature} className="flex items-center gap-2 text-sm text-slate-300">
                  <CheckCircle2 size={18} className="text-brand-300" />
                  {feature}
                </li>
              ))}
            </ul>
            <Button className="mt-8" full variant={user?.plan === plan.id ? 'secondary' : 'primary'} onClick={() => handleSelectPlan(plan.id)}>
              {user?.plan === plan.id ? 'Plano atual' : 'Selecionar plano'}
            </Button>
          </Card>
        ))}
      </div>
    </div>
  );
}
