import { useEffect, useState } from 'react';
import { Search } from 'lucide-react';
import { CampaignCard } from '../components/CampaignCard';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { useAuth } from '../contexts/AuthContext';
import { deleteCampaign, listCampaigns } from '../lib/campaigns';
import { Campaign } from '../types';
import { Link } from 'react-router-dom';

export function CampaignLibraryPage() {
  const { user } = useAuth();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    listCampaigns(user.id)
      .then(setCampaigns)
      .finally(() => setLoading(false));
  }, [user]);

  async function handleDelete(id: string) {
    if (!user) return;
    const confirmed = window.confirm('Deseja excluir esta campanha?');
    if (!confirmed) return;
    await deleteCampaign(id, user.id);
    setCampaigns((current) => current.filter((campaign) => campaign.id !== id));
  }

  const filtered = campaigns.filter((campaign) => {
    const text = `${campaign.product_name} ${campaign.channel} ${campaign.tone}`.toLowerCase();
    return text.includes(search.toLowerCase());
  });

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-black text-white">Minhas campanhas</h1>
          <p className="mt-2 text-slate-400">Todas as campanhas salvas ficam organizadas aqui.</p>
        </div>
        <Link to="/nova-campanha">
          <Button>Criar nova campanha</Button>
        </Link>
      </div>

      <div className="mb-6 flex items-center gap-3 rounded-2xl border border-white/10 bg-black/25 px-4 py-3">
        <Search size={18} className="text-slate-400" />
        <input
          className="w-full bg-transparent text-sm text-white outline-none placeholder:text-slate-500"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Buscar por produto, canal ou tom..."
        />
      </div>

      {loading ? (
        <p className="text-slate-400">Carregando campanhas...</p>
      ) : filtered.length === 0 ? (
        <Card className="text-center">
          <p className="text-lg font-bold text-white">Nenhuma campanha encontrada.</p>
          <p className="mt-2 text-slate-400">Crie uma campanha ou ajuste sua busca.</p>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((campaign) => (
            <CampaignCard key={campaign.id} campaign={campaign} onDelete={handleDelete} />
          ))}
        </div>
      )}
    </div>
  );
}
