import { Session } from '@supabase/supabase-js';
import { createContext, ReactNode, useContext, useEffect, useMemo, useState } from 'react';
import { PlanName, UserProfile } from '../types';
import { isSupabaseConfigured, supabase } from '../lib/supabase';

interface AuthContextValue {
  user: UserProfile | null;
  session: Session | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (name: string, email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (payload: Partial<Pick<UserProfile, 'name' | 'plan'>>) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);
const LOCAL_USER_KEY = 'divulgafacil_user';

function readLocalUser(): UserProfile | null {
  const raw = localStorage.getItem(LOCAL_USER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as UserProfile;
  } catch {
    return null;
  }
}

function saveLocalUser(user: UserProfile | null) {
  if (!user) {
    localStorage.removeItem(LOCAL_USER_KEY);
    return;
  }
  localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(user));
}

async function fetchProfile(userId: string, email: string): Promise<UserProfile> {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .single();

  if (!error && data) return data as UserProfile;

  const fallback: UserProfile = {
    id: userId,
    name: email.split('@')[0],
    email,
    plan: 'free',
  };

  const { data: inserted } = await supabase.from('users').insert(fallback).select('*').single();
  return (inserted || fallback) as UserProfile;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function boot() {
      if (!isSupabaseConfigured) {
        if (mounted) {
          setUser(readLocalUser());
          setLoading(false);
        }
        return;
      }

      const { data } = await supabase.auth.getSession();
      if (!mounted) return;

      setSession(data.session);
      if (data.session?.user) {
        const profile = await fetchProfile(
          data.session.user.id,
          data.session.user.email || 'usuario@email.com'
        );
        setUser(profile);
      }
      setLoading(false);
    }

    boot();

    if (!isSupabaseConfigured) return undefined;

    const { data: listener } = supabase.auth.onAuthStateChange(async (_event, nextSession) => {
      setSession(nextSession);
      if (nextSession?.user) {
        const profile = await fetchProfile(nextSession.user.id, nextSession.user.email || 'usuario@email.com');
        setUser(profile);
      } else {
        setUser(null);
      }
    });

    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  async function signIn(email: string, password: string) {
    if (!isSupabaseConfigured) {
      const localUser: UserProfile = {
        id: btoa(email).replaceAll('=', ''),
        name: email.split('@')[0],
        email,
        plan: 'free',
        created_at: new Date().toISOString(),
      };
      saveLocalUser(localUser);
      setUser(localUser);
      return;
    }

    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw new Error(error.message);
  }

  async function signUp(name: string, email: string, password: string) {
    if (!isSupabaseConfigured) {
      const localUser: UserProfile = {
        id: crypto.randomUUID(),
        name,
        email,
        plan: 'free',
        created_at: new Date().toISOString(),
      };
      saveLocalUser(localUser);
      setUser(localUser);
      return;
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { name } },
    });

    if (error) throw new Error(error.message);

    if (data.user) {
      const profile: UserProfile = {
        id: data.user.id,
        name,
        email,
        plan: 'free',
      };
      await supabase.from('users').upsert(profile);
      setUser(profile);
    }
  }

  async function signOut() {
    if (!isSupabaseConfigured) {
      saveLocalUser(null);
      setUser(null);
      return;
    }

    const { error } = await supabase.auth.signOut();
    if (error) throw new Error(error.message);
    setUser(null);
    setSession(null);
  }

  async function updateProfile(payload: Partial<Pick<UserProfile, 'name' | 'plan'>>) {
    if (!user) return;
    const nextUser = { ...user, ...payload };

    if (!isSupabaseConfigured) {
      saveLocalUser(nextUser);
      setUser(nextUser);
      return;
    }

    const { error } = await supabase.from('users').update(payload).eq('id', user.id);
    if (error) throw new Error(error.message);
    setUser(nextUser);
  }

  const value = useMemo(
    () => ({ user, session, loading, signIn, signUp, signOut, updateProfile }),
    [user, session, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth precisa estar dentro de AuthProvider');
  return context;
}
