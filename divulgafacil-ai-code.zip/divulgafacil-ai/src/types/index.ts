export type PlanName = 'free' | 'pro' | 'premium';

export type ProductType =
  | 'PDF'
  | 'Curso'
  | 'Serviço'
  | 'Produto físico'
  | 'Mentoria'
  | 'Outro';

export type CampaignTone =
  | 'Persuasivo'
  | 'Profissional'
  | 'Jovem'
  | 'Urgente'
  | 'Emocional'
  | 'Simples';

export type CampaignChannel =
  | 'WhatsApp'
  | 'Instagram'
  | 'TikTok'
  | 'Facebook'
  | 'Anúncio pago'
  | 'Página de vendas';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  plan: PlanName;
  created_at?: string;
}

export interface CampaignFormData {
  product_name: string;
  product_type: ProductType;
  price: string;
  target_audience: string;
  main_benefit: string;
  problem_solved: string;
  tone: CampaignTone;
  channel: CampaignChannel;
}

export interface GeneratedCampaignContent {
  title: string;
  product_description: string;
  whatsapp_messages: string[];
  instagram_captions: string[];
  post_ideas: string[];
  ad_headlines: string[];
  urgency_phrases: string[];
  ctas: string[];
  short_video_script: string;
}

export interface Campaign {
  id: string;
  user_id: string;
  product_name: string;
  product_type: ProductType;
  price: string;
  target_audience: string;
  main_benefit: string;
  problem_solved: string;
  tone: CampaignTone;
  channel: CampaignChannel;
  generated_content: GeneratedCampaignContent;
  created_at: string;
}

export interface Subscription {
  id: string;
  user_id: string;
  plan_name: PlanName;
  status: 'active' | 'inactive' | 'canceled' | 'past_due';
  started_at: string;
  expires_at?: string;
}
