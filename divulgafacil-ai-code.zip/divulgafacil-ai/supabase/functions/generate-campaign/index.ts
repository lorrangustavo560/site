// Supabase Edge Function opcional.
// Ative VITE_USE_AI_FUNCTION=true no .env e configure OPENAI_API_KEY nas secrets do Supabase.
// Comando: supabase secrets set OPENAI_API_KEY=sua_chave

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const apiKey = Deno.env.get('OPENAI_API_KEY');

    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'OPENAI_API_KEY não configurada.' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const prompt = `
Você é um especialista em copywriting, marketing digital e vendas online.
Crie uma campanha de divulgação persuasiva com base nas informações do produto.
O conteúdo deve ser claro, chamativo, direto e pronto para copiar e postar.
Evite promessas falsas, garantias irreais e exageros.
Use português do Brasil.

Dados do produto:
${JSON.stringify(body, null, 2)}

Retorne somente um JSON válido neste formato:
{
  "title": "string",
  "product_description": "string",
  "whatsapp_messages": ["string", "string", "string", "string", "string"],
  "instagram_captions": ["string", "string", "string", "string", "string"],
  "post_ideas": ["string", "string", "string", "string", "string"],
  "ad_headlines": ["string", "string", "string"],
  "urgency_phrases": ["string", "string", "string"],
  "ctas": ["string", "string", "string"],
  "short_video_script": "string"
}`;

    const aiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.8,
        response_format: { type: 'json_object' },
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      return new Response(JSON.stringify({ error: errorText }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const result = await aiResponse.json();
    const content = result.choices?.[0]?.message?.content;

    return new Response(content, {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Erro interno.' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
